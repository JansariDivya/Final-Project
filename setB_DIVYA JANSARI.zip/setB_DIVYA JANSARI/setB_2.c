#include <string.h>
#include <stdio.h>
#include<stdlib.h>

FILE *fp;
char a[10][100],b[10][100],str[100];

int main()
{
    int num,k;
    
    
    fp = fopen("main.txt","r");
    
    printf("\nEnter the string to find grandchildren of it \n");
    
    scanf("%s",str);
    
    for(int i=0;i<5;i++)
    {
        fscanf(fp,"%s\t%s",&a[i][100],&b[i][100]);

        if(strcmp(str,b[i]) == 0)

        k = i;
    }
    int count = 0;
    
    for(int i=0;i<5;i++)
        {
            
        if(strcmp(a[k],b[i]) == 0)
        
        count++;
        }
  
    printf("%d",count);
    printf("\n");
    fclose(fp);
    return 0;

}