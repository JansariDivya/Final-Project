#include<stdio.h>
#include<ctype.h>
#define max 100
#include<string.h>

char stack[max];
int top = -1;


void push (char ch)
{
  top++;
  stack[top] = ch;
}




int main ()
{
  char s[100];
  int len,flag=0,i,temp=0;
 
      printf ("\nEnter the length of the string\n");
      scanf ("%d", &len);
          if (1 <= len && len <= 100)
            {
              printf ("\nEnter the string which you want to reduce\n");
              scanf ("%s", s);
              printf("\n");
             
                 for(i=0;s[i];i++)
                 {
                     if(s[i]>='a'&&s[i]<='z')
                     {
		             flag=1;
		             temp=1;
                     }
                     else
                     {
		             flag=0;
		             temp=0;
                     }  
                 }
                
         
                    if((strlen(s)==len)&&(flag==1))
                    {
                    
                    	  //using Stack to reduce the string
                         for (int i = 0; s[i]; i++)
			     {
			        if (top != -1 && stack[top] == s[i])
			           top--;
			        else
			           push (s[i]);
			     }
			     
                          if (top == -1)
                    		printf ("\nEmpty String\n");
                          else
		            {
		             for (int i = 0; i <= top; i++)
		               printf ("%c", stack[i]);
		            }
                     }
                     
                    else
                    {  
                    	 if(temp==0)
                        printf("\nPlease enter lowercase characters in the string\n");
                        else if(temp==1)
                        printf("\nPlease Enter the string's Length based on the Input length Entered by you \n");
                    }
                   
            }        
          else
            {
              printf ("\nplease input length of the string between (1-100)\n");
            }
            
           printf("\n");

  return 0;
}