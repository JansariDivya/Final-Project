#include <stdio.h>
#include <stdlib.h>

#define CHAR_BITS  8 // size of character

#define INT_BITS  ( sizeof(int) * CHAR_BITS)


//print data in binary
void PrintInBinary(unsigned n)
{
	short int pos;
	
	for (pos = (INT_BITS -1) ; pos >= 0 ; pos--)
	{
	  (n & (1 << pos))? printf("1"): printf("0");	
	}
		
		

}


//bit reversal function
unsigned int ReverseTheBits(unsigned int num)
{
    unsigned int i = 0;
    unsigned int tmp = 0;         
    int iNumber = (INT_BITS - 1);
	     
  
    for(; i < iNumber; i++)
    {
	      
       tmp |= num & 1; 
       
       num >>= 1; 
       
       tmp <<= 1;  
       
    }
    
    
    return tmp;
}
 
int main()
{
    unsigned int data = 0;
    unsigned int Rev = 0;
    
    printf("\nEnter the number : \n");
    scanf("%u",&data);
    
    printf("\nBefore: " );
    PrintInBinary(data);
    
    
    Rev = ReverseTheBits(data);

    printf("\tAfter " );
    PrintInBinary(Rev);
    printf("\n");
return 0;
}